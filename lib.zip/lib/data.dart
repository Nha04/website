final List<Map<String, String>> laptops = [
  {'name': 'Laptop A', 'price': '\$1000', 'description': 'This is a laptop description.', 'image': 'assets/laptop/laptop_a.jpg'},
];

final List<Map<String, String>> desktops = [
  {'name': 'Desktop A', 'price': '\$800', 'image': 'assets/desktop/desktop_a.jpg'},
];

final List<Map<String, String>> keyboard = [
  {'name': 'Keyboard', 'price': '\$50', 'image': 'assets/keyboard/keyboard_a.jpg'},
];

final List<Map<String, String>> mouse = [
  {'name': 'Mouse', 'price': '\$30', 'image': 'assets/mouse/mouse_a.jpg'},
];

final List<Map<String, String>> headphone = [
  {'name': 'headphone', 'price': '\$50', 'image': 'assets/headphone/headphone_a.jpg'},
];

List<Map<String, String>> newArrivals = [
  {'name': 'New Laptop A', 'price': '\$1200', 'description': 'A new high-performance laptop.', 'image': 'assets/newarrival/new_laptop_a.jpg',},
];